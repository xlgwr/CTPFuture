tcpdirect客户端api使用需知

仅支持linux，且需要安装了solarflare网卡，型号8522 plus或更新，并安装了onload 版本201811/201811-u1。
满足上述条件下，替换so文件和头文件，重新编译客户端程序即可，如果你的api已经是3.1.3.54/55版本，则只需替换so应该就能使用。

其它注意事项：
1 在/etc/sysctl.conf文件中，增加一行：
vm.nr_hugepages=2048
需要重启服务器生效

2. 客户端启动前，需要保证有生效的成员变量：
export ZF_ATTR=interface=p4p1
其中的p4p1，是对应连接到我们20000端口的那个网口的设备名，需要根据机器实际情况修改。

3. /etc/modprobe.d/sfc.conf里增加一句
options sfc piobuf_size=0
重启服务器生效